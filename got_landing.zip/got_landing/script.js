(() => {
  const DEFAULT_CONTENT = {
    meta: {
      title: 'ИИ-аналитик личных данных — Telegram',
      description: 'Персональный аналитический разбор в Telegram: выберите тариф T0–T3 и получите отчёт за несколько минут.',
      brand: 'Numerolog Bot MVP',
    },
  };

  // Резервная копия текстового контента для случаев, когда загрузка
  // JSON не удалась (например, при открытии страницы по file://).
  const INLINE_CONTENT = {
    meta: {
      title: 'ИИ-аналитик личных данных — Telegram',
      description:
        'Персональный аналитический разбор в Telegram: выберите тариф T0–T3 и получите отчёт за несколько минут.',
      brand: 'Numerolog Bot MVP',
    },
    hero: {
      eyebrow: 'One-screen landing',
      title: 'Откройте карту своих сильных сторон',
      subtitle:
        'Короткий путь к личному разбору: выберите уровень отчёта и начните в Telegram.',
      primaryCta: 'Перейти в Telegram',
      secondaryCta: 'Смотреть тарифы',
    },
    benefits: {
      title: 'Преимущества',
      items: [
        {
          title: 'Быстрый старт',
          description: 'Без длинной регистрации — переход в бота по одной кнопке.',
        },
        {
          title: 'Гибкая глубина',
          description:
            'Форматы T0–T3: от ознакомительного до расширенного аналитического.',
        },
        {
          title: 'Удобный результат',
          description: 'Отчёт в Telegram + выгрузка PDF в один клик.',
        },
      ],
    },
    tariffs: {
      title: 'Тарифы T0–T3',
      items: [
        {
          id: 't0',
          title: 'T0',
          price: '0 ₽',
          description: 'Ознакомительный отчёт, доступно 1 раз в месяц.',
          cta: 'Выбрать T0',
          placement: 'tariff_t0',
        },
        {
          id: 't1',
          title: 'T1',
          price: 'от 990 ₽',
          description: 'Расширенный базовый отчёт по вашим данным.',
          cta: 'Выбрать T1',
          placement: 'tariff_t1',
        },
        {
          id: 't2',
          title: 'T2',
          price: 'от 2 490 ₽',
          description: 'Дополнительная анкета и углублённые сценарии развития.',
          cta: 'Выбрать T2',
          placement: 'tariff_t2',
          badge: 'Рекомендуем',
        },
        {
          id: 't3',
          title: 'T3',
          price: 'от 4 990 ₽',
          description: 'Максимальная глубина с месячным и годовым фокусом.',
          cta: 'Выбрать T3',
          placement: 'tariff_t3',
        },
      ],
    },
    prePaymentNotice: {
      title: 'Важно до оплаты в боте',
      consultationBlockTitle: 'Не является консультацией/прогнозом',
      consultationBlockText:
        'Сервис не является консультацией, прогнозом или рекомендацией к действию. Все выводы носят аналитический и описательный характер.',
      refundBlockTitle: 'Возвратов нет',
      refundBlockText:
        'Оплачивая доступ к отчёту, пользователь подтверждает согласие с офертой и условием «возвратов нет».',
      cta: 'Перейти в бот и выбрать тариф',
    },
    disclaimers: {
      title: 'Дисклеймеры',
      items: [
        'Сервис не является консультацией, прогнозом или рекомендацией к действию.',
        'Все выводы носят аналитический и описательный характер.',
        'Ответственность за решения остаётся за пользователем.',
        'Сервис не гарантирует финансовых или иных результатов.',
        'Возвратов нет.',
      ],
    },
    faq: {
      title: 'FAQ',
      items: [
        {
          question: 'Сколько времени занимает получение отчёта?',
          answer:
            'Обычно несколько минут после заполнения данных (и оплаты для T1–T3).',
        },
        {
          question: 'Можно ли начать бесплатно?',
          answer: 'Да, тариф T0 доступен бесплатно с ограничением 1 раз в месяц.',
        },
        {
          question: 'Где я получу результат?',
          answer: 'В Telegram-боте, также можно выгрузить PDF-версию отчёта.',
        },
      ],
    },
    footer: {
      cta: 'Открыть Telegram-бота',
      stickyCta: 'Перейти в Telegram',
    },
  };

  const getByPath = (obj, path) =>
    path
      .split('.')
      .reduce((acc, key) => (acc && key in acc ? acc[key] : null), obj);

  const setStaticContent = (content) => {
    document.querySelectorAll('[data-content]').forEach((element) => {
      const value = getByPath(content, element.dataset.content);
      if (typeof value === 'string') {
        element.textContent = value;
      }
    });
  };

  const renderBenefits = (content) => {
    const target = document.querySelector('#benefits-grid');
    if (!target) return;
    target.innerHTML = '';
    (content.benefits?.items || []).forEach((item) => {
      const article = document.createElement('article');
      article.className = 'card';
      article.innerHTML = `<h3>${item.title || ''}</h3><p>${item.description || ''}</p>`;
      target.appendChild(article);
    });
  };

  const renderTariffs = (content) => {
    const target = document.querySelector('#tariffs-grid');
    if (!target) return;
    target.innerHTML = '';
    (content.tariffs?.items || []).forEach((tariff) => {
      const isRecommended = Boolean(tariff.badge);
      const article = document.createElement('article');
      article.className = `card tariff${isRecommended ? ' tariff-recommended' : ''}`;
      article.innerHTML = `${isRecommended ? `<span class="badge">${tariff.badge}</span>` : ''}
        <p class="tariff-title">${tariff.title || ''}</p>
        <p class="tariff-price">${tariff.price || ''}</p>
        <p>${tariff.description || ''}</p>
        <a class="btn btn-primary js-telegram-cta js-tariff-cta" href="https://t.me/your_bot_username" data-placement="${tariff.placement || 'tariff_unknown'}" data-tariff="${tariff.id || 'na'}">${tariff.cta || 'Выбрать'}</a>`;
      target.appendChild(article);
    });
  };

  const renderDisclaimers = (content) => {
    const target = document.querySelector('#disclaimer-list');
    if (!target) return;
    target.innerHTML = '';
    (content.disclaimers?.items || []).forEach((item) => {
      const li = document.createElement('li');
      li.textContent = item;
      target.appendChild(li);
    });
  };

  const renderFaq = (content) => {
    const target = document.querySelector('#faq-list');
    if (!target) return;
    target.innerHTML = '';
    (content.faq?.items || []).forEach((item) => {
      const details = document.createElement('details');
      details.className = 'faq-item';
      details.innerHTML = `<summary>${item.question || ''}</summary><p>${item.answer || ''}</p>`;
      target.appendChild(details);
    });
  };

  const applyMeta = (content) => {
    const title = content.meta?.title || DEFAULT_CONTENT.meta.title;
    const description = content.meta?.description || DEFAULT_CONTENT.meta.description;
    const brand = content.meta?.brand || DEFAULT_CONTENT.meta.brand;
    document.title = title;
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) metaDescription.setAttribute('content', description);
    const footerBrand = document.querySelector('#footer-brand');
    if (footerBrand) footerBrand.textContent = `© ${brand}`;
  };

  const toSafeToken = (value, maxLength = 12) => {
    const normalized = String(value || 'na')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9_-]/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
    return (normalized || 'na').slice(0, maxLength);
  };

  const readAttribution = () => {
    const params = new URLSearchParams(window.location.search || '');
    return {
      source: toSafeToken(params.get('utm_source') || params.get('source') || 'na'),
      campaign: toSafeToken(params.get('utm_campaign') || params.get('campaign') || 'na'),
      medium: toSafeToken(params.get('utm_medium') || 'na'),
      content: toSafeToken(params.get('utm_content') || 'na'),
      term: toSafeToken(params.get('utm_term') || 'na'),
    };
  };

  const attribution = readAttribution();

  const makeStartPayload = (placement) => {
    const safePlacement = toSafeToken(placement || 'unknown');
    let payload = ['lnd', `src_${attribution.source}`, `cmp_${attribution.campaign}`, `pl_${safePlacement}`].join('.');
    if (payload.length > 64) {
      payload = [
        'lnd',
        `src_${toSafeToken(attribution.source, 8)}`,
        `cmp_${toSafeToken(attribution.campaign, 8)}`,
        `pl_${toSafeToken(safePlacement, 8)}`,
      ].join('.');
    }
    return payload.slice(0, 64);
  };

  const buildTelegramUrl = (baseUrl, placement) => {
    try {
      const url = new URL(baseUrl);
      url.searchParams.set('start', makeStartPayload(placement));
      return url.toString();
    } catch (_error) {
      return baseUrl;
    }
  };

  const emitAnalytics = (eventName, payload = {}) => {
    const eventPayload = {
      event: eventName,
      event_id:
        (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function' && crypto.randomUUID()) ||
        `evt_${Date.now()}_${Math.random().toString(16).slice(2, 10)}`,
      ts: new Date().toISOString(),
      page: window.location.href,
      source: attribution.source,
      campaign: attribution.campaign,
      medium: attribution.medium,
      content: attribution.content,
      term: attribution.term,
      ...payload,
    };
    if (Array.isArray(window.dataLayer)) window.dataLayer.push(eventPayload);
    if (typeof window.gtag === 'function') window.gtag('event', eventName, eventPayload);
    return eventPayload;
  };

  const bindInteractions = () => {
    const faqItems = document.querySelectorAll('.faq-item');
    const faqSection = document.querySelector('#faq');
    const heroSection = document.querySelector('.hero');
    const telegramCtas = document.querySelectorAll('.js-telegram-cta');
    const tariffCtas = document.querySelectorAll('.js-tariff-cta');

    faqItems.forEach((item) => {
      item.addEventListener('toggle', () => {
        if (!item.open) return;
        faqItems.forEach((other) => {
          if (other !== item) other.open = false;
        });
      });
    });

    telegramCtas.forEach((cta) => {
      const placement = cta.dataset.placement || 'unknown';
      const nextUrl = buildTelegramUrl(cta.href, placement);
      cta.href = nextUrl;
      cta.addEventListener('click', () => {
        const startPayload = new URL(nextUrl).searchParams.get('start') || 'na';
        emitAnalytics('landing_cta_click', {
          placement,
          target: nextUrl,
          start_payload: startPayload,
        });
      });
    });

    tariffCtas.forEach((cta) => {
      cta.addEventListener('click', () => {
        const placement = cta.dataset.placement || 'unknown';
        const tariff = toSafeToken(cta.dataset.tariff || 'na', 4);
        emitAnalytics('landing_tariff_click', {
          placement,
          tariff,
          target: cta.href,
          start_payload: new URL(cta.href).searchParams.get('start') || 'na',
        });
      });
    });

    const observeSectionOnce = (element, eventName, sectionName) => {
      if (!element || typeof IntersectionObserver === 'undefined') return;
      let sent = false;
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (sent || !entry.isIntersecting) return;
            sent = true;
            emitAnalytics(eventName, { section: sectionName });
            observer.disconnect();
          });
        },
        { threshold: 0.35 }
      );
      observer.observe(element);
    };

    observeSectionOnce(heroSection, 'landing_hero_view', 'hero');
    observeSectionOnce(faqSection, 'landing_faq_reach', 'faq');
  };

  const init = async () => {
    let content = DEFAULT_CONTENT;
    try {
      const response = await fetch('content/landing-content.json', { cache: 'no-store' });
      if (response.ok) {
        const payload = await response.json();
        content = { ...DEFAULT_CONTENT, ...payload };
      }
    } catch (_error) {
      // Если загрузить не удалось, используем встроенный контент.
      content = { ...DEFAULT_CONTENT, ...INLINE_CONTENT };
    }
    // Если после попытки загрузить JSON полученные данные не содержат ключевые
    // секции (например, при открытии по file://), используем INLINE_CONTENT.
    if (!content.hero) {
      content = { ...DEFAULT_CONTENT, ...INLINE_CONTENT };
    }
    applyMeta(content);
    setStaticContent(content);
    renderBenefits(content);
    renderTariffs(content);
    renderDisclaimers(content);
    renderFaq(content);
    bindInteractions();
  };

  init();
})();